Hello,
Thank you for visiting thevbprogrammer.com. I hope you find this download useful. If you have already purchased the e-book or have made a donation, thank you very much. If not, please consider supporting the site by either:
(a) purchasing an e-book on the Shop page, or 
(b) making a donation on either through the Contact page or 
    by sending a check or money order for any amount (payable to "thevbprogrammer.com") to:

            thevbprogrammer.com
            P.O. Box 50
            Maple Shade, NJ 08052
            (USA)

Thank you, your support is appreciated.
Happy programming!
